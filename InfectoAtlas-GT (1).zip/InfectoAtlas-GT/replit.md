# Running InfectoAtlas GT on Replit

This project uses React, Vite, and Bun.

- Install dependencies with `bun install`.
- Start the Replit preview with `bun run dev`. The Vite server listens on port 5000 and allows Replit's proxied hosts.
- Create a production build with `bun run build`.

The current academic document analyzer is rule-based and does not require a Gemini API key to run.