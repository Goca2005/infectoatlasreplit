---
name: Alcance de InfectoAtlas GT
description: Instrucciones permanentes para continuar el proyecto importado sin reemplazarlo ni adelantar funciones nuevas.
---

Trabajar sobre el repositorio existente de InfectoAtlas GT; no crear una aplicación nueva. Verificar primero que la aplicación original funcione en la plataforma. Conservar su código, diseño y datos, y avanzar progresivamente sin implementar funciones nuevas antes de confirmar que lo existente funciona.

**Why:** el usuario pidió expresamente continuar sobre el proyecto importado y respetar este orden.

**How to apply:** al iniciar cambios en InfectoAtlas GT, comprobar el estado actual, limitar las modificaciones a lo que el usuario pidió y posponer funciones futuras hasta que la aplicación existente esté verificada.

Los datos guardados en localStorage de AI Studio no se migran automáticamente al dominio de Replit. No afirmar que se recuperaron; solo importarlos desde un archivo JSON exportado en la instancia original. Si no se cuenta con ese archivo, explicar la limitación y no limpiar ni modificar el almacenamiento del navegador.

**Why:** los datos del navegador pertenecen al origen donde se guardaron; el usuario pidió no atribuir al proyecto datos que no hayan sido exportados e importados.

**How to apply:** antes de restaurar datos de AI Studio, pedir que el usuario exporte el JSON desde esa instancia y mostrar una vista previa en Replit antes de cambiar el almacenamiento local.