import { describe, expect, test } from 'bun:test';
import { OFFICIAL_BIBLIOGRAPHY } from '../src/data/bibliography.ts';
import { INITIAL_MICROORGANISMS } from '../src/data/microorganisms.ts';
import { LocalStorageRepository } from '../src/services/storageService.ts';

class MemoryStorage {
  values = new Map();

  getItem(key) {
    return this.values.has(key) ? this.values.get(key) : null;
  }

  setItem(key, value) {
    this.values.set(key, String(value));
  }

  removeItem(key) {
    this.values.delete(key);
  }
}

function makeData() {
  const microorganisms = structuredClone(INITIAL_MICROORGANISMS);
  microorganisms[0] = {
    ...microorganisms[0],
    commonName: `${microorganisms[0].commonName} (editado en prueba)`
  };
  const customMicroorganism = {
    ...structuredClone(microorganisms[0]),
    id: 'test-custom-microorganism',
    scientificName: 'Testium inventum',
    commonName: 'Registro personalizado de prueba'
  };

  return {
    microorganisms: [...microorganisms, customMicroorganism],
    academicDocuments: [{
      id: 'test-document',
      title: 'Guía de prueba',
      subject: 'Parasitología',
      authorOrInstitution: 'Universidad de prueba',
      yearOrEdition: '2026',
      sourceTier: 'Apunte universitario',
      uploadDate: '2026-10-03',
      pageCount: 1,
      fileName: 'guia-original.pdf',
      fileSizeBytes: 1200,
      processingStatus: 'Extracción completada',
      pages: [{
        pageNumber: 1,
        textContent: 'Texto extraído que debe sobrevivir al respaldo.',
        hasExtractableText: true,
        charCount: 47,
        detectedMicroorganisms: ['Testium inventum']
      }],
      unextractablePagesCount: 0,
      extractedProposalsCount: 1,
      summaryNotes: 'Nota de prueba'
    }],
    extractionProposals: [{
      id: 'test-proposal',
      documentId: 'test-document',
      documentTitle: 'Guía de prueba',
      sourceTier: 'Apunte universitario',
      sourcePage: 1,
      sourceSnippet: 'Fragmento fuente',
      targetMicroorganismId: 'test-custom-microorganism',
      targetMicroorganismName: 'Testium inventum',
      isNewOrganism: true,
      field: 'Nueva ficha de microorganismo',
      previousValue: null,
      proposedValue: 'Dato científico aprobado para la prueba',
      potentialContradiction: null,
      verificationStatus: 'En proceso de validación',
      status: 'aprobado',
      reviewedAt: '2026-10-03T12:00:00.000Z'
    }],
    auditLogs: [{
      id: 'test-audit',
      timestamp: '2026-10-03T12:00:00.000Z',
      documentTitle: 'Guía de prueba',
      sourcePage: 1,
      microorganismId: 'test-custom-microorganism',
      microorganismName: 'Testium inventum',
      field: 'Nueva ficha de microorganismo',
      previousValue: null,
      newValue: 'Dato científico aprobado para la prueba',
      action: 'aprobado'
    }],
    bookmarks: ['test-custom-microorganism'],
    bibliographyReferences: [
      ...structuredClone(OFFICIAL_BIBLIOGRAPHY),
      {
        id: 'test-reference',
        title: 'Referencia de prueba',
        institutionOrAuthors: 'Autora de prueba',
        type: 'Artículo Científico',
        year: '2026',
        organization: 'Literatura Médica Académica',
        status: 'Revisado',
        urlOrCitation: 'DOI de prueba',
        notes: 'Fuente personalizada'
      }
    ],
    userSettings: { language: 'es', displayDensity: 'compacta' }
  };
}

describe('respaldo versionado de InfectoAtlas GT', () => {
  test('round-trip conserva fichas editadas, registros personalizados y todos los datos respaldables', async () => {
    const data = makeData();
    const source = new LocalStorageRepository(new MemoryStorage());
    const json = await source.exportBackupJSON(data);
    const parsed = JSON.parse(json);

    expect(parsed.format).toBe('infectoatlas-gt-backup');
    expect(parsed.schemaVersion).toBe(1);
    expect(parsed.appVersion).toBeString();
    expect(parsed.integrity.algorithm).toBe('SHA-256');
    expect(parsed.files.originalFileBytesIncluded).toBe(false);
    expect(parsed.files.omittedOriginalFiles[0].fileName).toBe('guia-original.pdf');

    const target = new LocalStorageRepository(new MemoryStorage());
    const current = await target.getBackupData();
    const plan = await target.inspectBackupJSON(json, current);
    expect(plan.valid).toBe(true);
    expect(plan.integrityStatus).toBe('verified');
    expect(plan.warnings.some(warning => warning.includes('archivos PDF/TXT/MD originales'))).toBe(true);

    const restored = await target.applyBackupImport(plan, 'restore', current);
    expect(restored).toEqual(data);
    expect(await target.getMicroorganisms()).toEqual(data.microorganisms);
    expect(target.getAcademicDocuments()).toEqual(data.academicDocuments);
    expect(target.getExtractionProposals()).toEqual(data.extractionProposals);
    expect(target.getAuditLogs()).toEqual(data.auditLogs);
    expect(target.getBookmarks()).toEqual(data.bookmarks);
    expect(target.getUserBibliographyReferences()).toEqual([
      data.bibliographyReferences.at(-1)
    ]);
    expect(target.getUserSettings()).toEqual(data.userSettings);
  });

  test('rechaza un respaldo modificado antes de escribir en localStorage', async () => {
    const source = new LocalStorageRepository(new MemoryStorage());
    const json = await source.exportBackupJSON(makeData());
    const parsed = JSON.parse(json);
    parsed.data.userSettings.language = 'alterado';

    const targetStorage = new MemoryStorage();
    const target = new LocalStorageRepository(targetStorage);
    const current = await target.getBackupData();
    const plan = await target.inspectBackupJSON(JSON.stringify(parsed), current);

    expect(plan.valid).toBe(false);
    expect(plan.errors.join(' ')).toContain('SHA-256 no coincide');
    await expect(target.applyBackupImport(plan, 'restore', current)).rejects.toThrow('no pasó la validación');
    expect(targetStorage.values.size).toBe(0);
  });

  test('migra el formato anterior de AI Studio, avisa campos ausentes y conserva secciones locales', async () => {
    const storage = new MemoryStorage();
    const target = new LocalStorageRepository(storage);
    const current = await target.getBackupData();
    const priorMicroorganisms = current.microorganisms;
    const legacy = {
      appletName: 'InfectoAtlas GT',
      version: '3.1.0',
      exportedAt: '2026-01-01T00:00:00.000Z',
      academicDocuments: [{
        id: 'legacy-doc',
        title: 'Documento heredado',
        fileName: 'legacy.pdf',
        pages: [{ pageNumber: 1, textContent: 'Texto antiguo' }]
      }]
    };

    const plan = await target.inspectBackupJSON(JSON.stringify(legacy), current);
    expect(plan.valid).toBe(true);
    expect(plan.sourceFormat).toBe('legacy-ai-studio');
    expect(plan.integrityStatus).toBe('legacy-unverified');
    expect(plan.warnings.some(warning => warning.includes('microorganisms'))).toBe(true);
    expect(plan.warnings.some(warning => warning.includes('El respaldo antiguo no incluye'))).toBe(true);
    expect(plan.omittedOriginalFiles).toEqual(['legacy.pdf']);

    const restored = await target.applyBackupImport(plan, 'restore', current);
    expect(restored.academicDocuments).toEqual(legacy.academicDocuments);
    expect(restored.microorganisms).toEqual(priorMicroorganisms);
    expect(storage.getItem('infectoatlas_microorganisms_v3')).toBeNull();
  });

  test('fusiona sin sobrescribir registros locales con el mismo id', async () => {
    const incoming = makeData();
    const current = makeData();
    const localName = 'Versión local que debe prevalecer';
    current.microorganisms[0].commonName = localName;
    const target = new LocalStorageRepository(new MemoryStorage());
    const json = await target.exportBackupJSON(incoming);
    const plan = await target.inspectBackupJSON(json, current);

    expect(plan.valid).toBe(true);
    expect(plan.duplicatesWithCurrent.microorganisms?.length).toBeGreaterThan(0);
    const merged = await target.applyBackupImport(plan, 'merge', current);
    expect(merged.microorganisms[0].commonName).toBe(localName);
    expect(merged.microorganisms.some(item => item.id === 'test-custom-microorganism')).toBe(true);
  });

  test('bloquea ids duplicados dentro del propio respaldo', async () => {
    const target = new LocalStorageRepository(new MemoryStorage());
    const current = await target.getBackupData();
    const backup = {
      appletName: 'InfectoAtlas GT',
      microorganisms: [
        { id: 'duplicado', scientificName: 'Primera especie' },
        { id: 'duplicado', scientificName: 'Segunda especie' }
      ]
    };
    const plan = await target.inspectBackupJSON(JSON.stringify(backup), current);

    expect(plan.valid).toBe(false);
    expect(plan.duplicatesInBackup.microorganisms).toEqual(['duplicado']);
  });

  test('detiene la exportación si una colección local está dañada, en vez de sustituirla por valores iniciales', async () => {
    const storage = new MemoryStorage();
    storage.setItem('infectoatlas_academic_docs_v3', '{no es json');
    const repository = new LocalStorageRepository(storage);

    await expect(repository.exportBackupJSON(makeData())).rejects.toThrow('No se exportó el respaldo');
  });

  test('revierte escrituras parciales cuando el navegador rechaza una sección', async () => {
    class OneTimeFailStorage extends MemoryStorage {
      failed = false;

      setItem(key, value) {
        if (key === 'infectoatlas_proposals_v3' && !this.failed) {
          this.failed = true;
          throw new Error('quota exceeded');
        }
        super.setItem(key, value);
      }
    }

    const storage = new OneTimeFailStorage();
    storage.setItem('infectoatlas_microorganisms_v3', JSON.stringify([{ id: 'local', scientificName: 'Localium' }]));
    storage.failed = false;
    const target = new LocalStorageRepository(storage);
    const current = await target.getBackupData({
      microorganisms: [{ id: 'local', scientificName: 'Localium' }],
      academicDocuments: [],
      extractionProposals: [],
      auditLogs: [],
      bookmarks: [],
      bibliographyReferences: structuredClone(OFFICIAL_BIBLIOGRAPHY),
      userSettings: {}
    });
    const json = await target.exportBackupJSON(makeData());
    const plan = await target.inspectBackupJSON(json, current);
    await expect(target.applyBackupImport(plan, 'restore', current)).rejects.toThrow('Los datos anteriores fueron restaurados');
    expect(JSON.parse(storage.getItem('infectoatlas_microorganisms_v3'))).toEqual([
      { id: 'local', scientificName: 'Localium' }
    ]);
    expect(storage.getItem('infectoatlas_academic_docs_v3')).toBeNull();
  });
});